default['locale']['lang'] = 'en_US.utf8'
default['locale']['lc_all'] = 'en_US.utf8'
